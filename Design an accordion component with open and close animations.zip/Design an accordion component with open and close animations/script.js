// Wait for the DOM to load
document.addEventListener("DOMContentLoaded", function() {
    const headers = document.querySelectorAll(".accordion-header");

    headers.forEach(header => {
        header.addEventListener("click", function() {
            // Toggle the content associated with the clicked header
            const content = this.nextElementSibling;

            // If content is open, close it
            if (content.classList.contains("open")) {
                content.classList.remove("open");
                content.style.height = "0px";
                setTimeout(() => content.style.display = "none", 500);
            } else {
                // Close all open contents
                document.querySelectorAll(".accordion-content.open").forEach(openContent => {
                    openContent.classList.remove("open");
                    openContent.style.height = "0px";
                    setTimeout(() => openContent.style.display = "none", 500);
                });

                // Open the selected content
                content.classList.add("open");
                content.style.display = "block";
                content.style.height = content.scrollHeight + "px";
            }
        });
    });
});