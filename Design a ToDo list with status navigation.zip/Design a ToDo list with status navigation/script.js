// script.js

function moveToNextStatus(button) {
    const todoItem = button.parentElement;
    const currentList = todoItem.parentElement;

    if (currentList.id === "backlog-list") {
        document.getElementById("todo-list").appendChild(todoItem);
    } else if (currentList.id === "todo-list") {
        document.getElementById("ongoing-list").appendChild(todoItem);
    } else if (currentList.id === "ongoing-list") {
        document.getElementById("done-list").appendChild(todoItem);
    }

    // Update button states for the moved item
    updateButtonStates(todoItem);
}

function moveToPreviousStatus(button) {
    const todoItem = button.parentElement;
    const currentList = todoItem.parentElement;

    if (currentList.id === "done-list") {
        document.getElementById("ongoing-list").appendChild(todoItem);
    } else if (currentList.id === "ongoing-list") {
        document.getElementById("todo-list").appendChild(todoItem);
    } else if (currentList.id === "todo-list") {
        document.getElementById("backlog-list").appendChild(todoItem);
    }

    // Update button states for the moved item
    updateButtonStates(todoItem);
}

function updateButtonStates(todoItem) {
    const currentListId = todoItem.parentElement.id;
    const leftButton = todoItem.querySelector(".left-btn");
    const rightButton = todoItem.querySelector(".right-btn");

    // Update button states based on the current list
    if (currentListId === "backlog-list") {
        leftButton.disabled = true;  // Disable left button for Backlog
        rightButton.disabled = false;  // Enable right button
    } else if (currentListId === "todo-list") {
        leftButton.disabled = false;  // Enable both buttons for To Do
        rightButton.disabled = false;
    } else if (currentListId === "ongoing-list") {
        leftButton.disabled = false;  // Enable both buttons for Ongoing
        rightButton.disabled = false;
    } else if (currentListId === "done-list") {
        leftButton.disabled = false;  // Enable left button for Done
        rightButton.disabled = true;  // Disable right button for Done
    }
}

// Initialize button states for all items at startup
document.querySelectorAll(".todo-item").forEach((item) => updateButtonStates(item));
