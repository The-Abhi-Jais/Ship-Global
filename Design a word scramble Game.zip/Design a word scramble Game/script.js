const words = [
    { word: "EXCHANGE", scrambled: "AEGEXCNH", hint: "The act of trading" },
    { word: "FROG", scrambled: "GROF", hint: "Can survive on Land and in water"},
    { word: "HOUSE", scrambled: "ESUOH", hint: "A building for living"},
    { word: "CAT", scrambled: "TAC", hint: "A small domesticated"}
     // You can add more words here
];

let currentWordIndex = 0;
let attempts = 0;
let timer;
let timeLeft = 15;

function startTimer() {
    timer = setInterval(() => {
        timeLeft--;
        document.getElementById('timer').innerText = `${timeLeft}s`;
        if (timeLeft <= 0) {
            clearInterval(timer);
            document.getElementById('feedback').innerText = "Time's up! Try again!";
            document.getElementById('checkWord').disabled = true;
        }
    }, 1000);
}

function resetGame() {
    clearInterval(timer);
    timeLeft = 15;
    document.getElementById('timer').innerText = `${timeLeft}s`;
    document.getElementById('checkWord').disabled = false;
    attempts = 0;
    document.getElementById('attempts').innerText = `Attempts: ${attempts}`;
    document.getElementById('feedback').innerText = '';
    document.getElementById('guessInput').value = '';
    startTimer();
}

function refreshWord() {
    currentWordIndex = (currentWordIndex + 1) % words.length;
    document.getElementById('scrambledWord').innerText = words[currentWordIndex].scrambled;
    document.querySelector('.hint').innerText = `Hint: ${words[currentWordIndex].hint}`;
    resetGame();
}

function checkWord() {
    const userGuess = document.getElementById('guessInput').value.toUpperCase();
    attempts++;
    document.getElementById('attempts').innerText = `Attempts: ${attempts}`;
    if (userGuess === words[currentWordIndex].word) {
        document.getElementById('feedback').innerText = "Correct! Well done!";
        clearInterval(timer);
        document.getElementById('checkWord').disabled = true;
    } else {
        document.getElementById('feedback').innerText = "Incorrect guess. Try again!";
    }
}

document.getElementById('refreshWord').addEventListener('click', refreshWord);
document.getElementById('checkWord').addEventListener('click', checkWord);

// Start the game
refreshWord();